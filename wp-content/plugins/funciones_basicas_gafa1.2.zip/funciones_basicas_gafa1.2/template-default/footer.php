	<div id="w_f"><?php wp_footer();?></div>
    </body>
</html>