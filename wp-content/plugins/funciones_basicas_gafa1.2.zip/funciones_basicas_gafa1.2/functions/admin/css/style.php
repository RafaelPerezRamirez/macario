<style type="text/css">
#adminmenu li.wp-menu-separator {
	background: #F1F1F1;
	border-right: 1px solid;
}
#wp-admin-bar-wp-logo, #contextual-help-link-wrap, #footer-thankyou, #footer-upgrade, #screen-options-link-wrap{
	display:none !important;
}
</style>