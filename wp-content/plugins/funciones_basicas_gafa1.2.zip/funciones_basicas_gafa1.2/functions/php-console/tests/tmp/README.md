This dir must be writable to execute tests
