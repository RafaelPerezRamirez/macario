<?php

undefined();
